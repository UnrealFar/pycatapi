from pycatapi import Cat

cat = Cat.get_cat()
print(cat)