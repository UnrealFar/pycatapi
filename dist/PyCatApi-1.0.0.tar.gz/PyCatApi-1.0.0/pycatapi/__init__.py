from .cats import *

__title__ = "PyCatAas"
__version__ = "1.0.0"
__author__ = "TheFarGG"